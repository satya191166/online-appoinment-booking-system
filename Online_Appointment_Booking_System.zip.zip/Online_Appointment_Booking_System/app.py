from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3

app = Flask(__name__)
app.secret_key = "online_appointment_secret"


def init_db():
    conn = sqlite3.connect("appointments.db")
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            department TEXT,
            doctor TEXT,
            date TEXT,
            time TEXT
        )
    """)

    conn.commit()
    conn.close()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]

        session["username"] = username

        return redirect(url_for("appointment"))

    return render_template("login.html")


@app.route("/register")
def register():
    return render_template("register.html")


@app.route("/appointment", methods=["GET", "POST"])
def appointment():

    if request.method == "POST":

        name = request.form["name"]
        email = request.form["email"]
        department = request.form["department"]
        doctor = request.form["doctor"]
        date = request.form["date"]
        time = request.form["time"]

        conn = sqlite3.connect("appointments.db")
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO appointments
            (name, email, department, doctor, date, time)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (name, email, department, doctor, date, time))

        conn.commit()
        conn.close()

        return render_template(
            "confirmation.html",
            name=name,
            email=email,
            department=department,
            doctor=doctor,
            date=date,
            time=time
        )

    return render_template("appointment.html")


@app.route("/appointments")
def view_appointments():

    conn = sqlite3.connect("appointments.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM appointments")
    appointments = cursor.fetchall()

    conn.close()

    return render_template(
        "appointments.html",
        appointments=appointments
    )


@app.route("/delete/<int:id>")
def delete_appointment(id):

    conn = sqlite3.connect("appointments.db")
    cursor = conn.cursor()

    cursor.execute(
        "DELETE FROM appointments WHERE id = ?",
        (id,)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("view_appointments"))

@app.route("/logout")
def logout():



    
    session.clear()
    return "You have been logged out successfully!"

    

init_db()


if __name__ == "__main__":
    app.run(debug=True)